package com.example.digitalhouse.floatbuttonbase;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class Main2Fragment extends Fragment {
    // Esto sirve para no equivocarse al escribir la clave. Para que sea única
    // public para que pueda ser accedido desde otra clase
    // static significa que es un atributo de la clase y no de la instancia. Main2Activity.KEY_MENSAJE
    // final que es constante y no se puede modificar.
    public final static String KEY_MENSAJE = "mensaje";
    public final static String KEY_REGALOS = "regalos";

    private String mensaje;
    private String regalos;

    public Main2Fragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mensaje = getArguments().getString(KEY_MENSAJE);
            regalos = getArguments().getString(KEY_REGALOS);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_main2, container, false);

        // Busco los textview en la vista
        TextView textViewMensaje = view.findViewById(R.id.textViewMensaje);
        TextView textViewRegalos = view.findViewById(R.id.textViewRegalos);

        // Seteo los textview con los valores
        textViewMensaje.setText(mensaje);

        // Si el valor de regalos es vacio. Imprime no hay regalos
        if (regalos.equals("")){
            textViewRegalos.setText("no hay regalos");
        } else {
            textViewRegalos.setText(regalos);
        }

        return view;
    }
}
