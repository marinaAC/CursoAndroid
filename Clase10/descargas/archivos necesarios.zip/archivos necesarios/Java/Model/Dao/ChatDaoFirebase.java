package com.digitalhouse.whatsappchatmio.Model.Dao;

import android.content.Context;

import com.digitalhouse.whatsappchatmio.Model.Pojo.ChatMessaje;
import com.digitalhouse.whatsappchatmio.Util.ResultListener;

import java.util.List;


/**
 * Created by joe on 4/9/18.
 */

public class ChatDaoFirebase {
    // TODO Descomentar esta linea, una vez agregadas las dependencias de Firebase
    //private DatabaseReference mDatabase;

    public void getChatMessajes(final Context context, final ResultListener<List<ChatMessaje>> escuchadorDelControlador) {
      // TODO
    }

    public void putChatMessaje(ChatMessaje messageToWrite) {
      // TODO
    }

}
