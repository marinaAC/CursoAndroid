
package com.example.digitalhouse.floatbuttonbase;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements MainFragment.OnSendToSanta{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creo el Fragment
        MainFragment mainFragment = new MainFragment();

        // Realizo la transacción
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.contenedorMain, mainFragment);
        fragmentTransaction.commit();
    }


    @Override
    public void onSendToSanta(String mensaje, String regalos) {
        //-------- MANDAR LOS DATOS A DONDE CORRESPONDA --------//

        // Creo el Intent
        Intent intent = new Intent(MainActivity.this, Main2Activity.class);

        // Creo el Bundle
        Bundle bundle = new Bundle();

        // Inserto valores al Bundle
        bundle.putString(Main2Fragment.KEY_MENSAJE, mensaje);
        bundle.putString(Main2Fragment.KEY_REGALOS, regalos);

        // Asocio el Bundle al Intent
        intent.putExtras(bundle);

        // Lanzo el Intent
        startActivity(intent);
    }
}
