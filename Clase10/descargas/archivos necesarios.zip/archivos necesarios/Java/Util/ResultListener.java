package com.digitalhouse.whatsappchatmio.Util;

/**
 * Created by joe on 4/9/18.
 */

public interface ResultListener<T> {
    void finish(T resultado);
}
