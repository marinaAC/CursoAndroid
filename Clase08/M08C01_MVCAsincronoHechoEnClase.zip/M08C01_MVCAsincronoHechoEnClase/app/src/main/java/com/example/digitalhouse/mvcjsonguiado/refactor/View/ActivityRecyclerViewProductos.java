package com.example.digitalhouse.mvcjsonguiado.refactor.View;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.digitalhouse.mvcjsonguiado.R;
import com.example.digitalhouse.mvcjsonguiado.refactor.Controller.Adapter;
import com.example.digitalhouse.mvcjsonguiado.refactor.Controller.ProductoController;
import com.example.digitalhouse.mvcjsonguiado.refactor.Model.Producto;
import com.example.digitalhouse.mvcjsonguiado.refactor.Utils.ResultListener;

import java.util.ArrayList;
import java.util.List;

public class ActivityRecyclerViewProductos extends AppCompatActivity {
    private List<Producto> productos = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_producto_v4);

        cargarProductos();

        //Toast.makeText(this,productos.toString(),Toast.LENGTH_SHORT).show();


        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        // Creo el Manager
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        // Seteo el Manager
        recyclerView.setLayoutManager(linearLayoutManager);
        // Mejoro la performance
        recyclerView.setHasFixedSize(true);
        // Creo el Adapter
        Adapter adapter = new Adapter(productos);
        // Seteo el Adapter al Recycle
        recyclerView.setAdapter(adapter);


    }

    public void cargarProductos(){
        //TODO: Aca le pido al controlador que me pase los productos y melos guardo
        ProductoController productoController = new ProductoController();


        // Creo mi telefono
        ResultListener<List<Producto>> telVista = new ResultListener<List<Producto>>() {

            @Override
            public void finish(List<Producto> resultado) {
                // LLEGARON LOS DATOS. REFRESCAR
            }
        };

        // Pido los datos al Controller y le paso mi telefono
        productoController.obtenerProductos(telVista);
    }
}


