package com.example.digitalhouse.mvcjsonguiado.refactor.utils;

/**
 * Created by digitalhouse on 18/01/18.
 */

public interface ResultListener<T> {
    void finish(T resultado);
}
