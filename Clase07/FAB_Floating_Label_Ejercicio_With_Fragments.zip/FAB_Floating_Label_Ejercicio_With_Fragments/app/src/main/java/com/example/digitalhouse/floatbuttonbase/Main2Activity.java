package com.example.digitalhouse.floatbuttonbase;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Busco el intent con el cual fui invocado
        Intent intent = getIntent();
        // Le quito el Bundle
        Bundle bundle = intent.getExtras();

        // Creo el Fragment
        Main2Fragment main2Fragment = new Main2Fragment();
        // Le paso el Bundle al Fragment
        main2Fragment.setArguments(bundle);


        // Realizo la transacción
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.contenedorSecond, main2Fragment);
        fragmentTransaction.commit();
    }
}
